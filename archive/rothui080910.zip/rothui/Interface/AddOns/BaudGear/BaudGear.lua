--[[Idea list:
Option for no minimap button
Option for forced empty slots
]]

BaudGearDebug = false;

local SelectedSet;

--[[local EquipSlot = {
  {Slot = 1, Name = "HeadSlot"},
  {Slot = 2, Name = "NeckSlot"},
  {Slot = 3, Name = "ShoulderSlot"},
  {Slot = 5, Name = "ChestSlot"},
  {Slot = 6, Name = "WaistSlot"},

  {Slot = 7, Name = "LegsSlot"},
  {Slot = 8, Name = "FeetSlot"},
  {Slot = 9, Name = "WristSlot"},
  {Slot = 10, Name = "HandsSlot"},
  {Slot = 15, Name = "BackSlot"},

  {Slot = 11, Name = "Finger0Slot"},
  {Slot = 12, Name = "Finger1Slot"},
  {Slot = 13, Name = "Trinket0Slot"},
  {Slot = 14, Name = "Trinket1Slot"},
  {Slot = 18, Name = "RangedSlot"},

--  false, false, false,
  {Slot = 16, Name = "MainHandSlot"},
  {Slot = 17, Name = "SecondaryHandSlot"}
};]]


local EquipSlot = {
  {Name = "HeadSlot"},
  {Name = "NeckSlot"},
  {Name = "ShoulderSlot"},
  {Name = "BackSlot"},
  {Name = "ChestSlot"},

  {Name = "WristSlot"},
  {Name = "HandsSlot"},
  {Name = "WaistSlot"},
  {Name = "LegsSlot"},
  {Name = "FeetSlot"},

  {Name = "RangedSlot"},
  {Name = "Finger0Slot"},
  {Name = "Finger1Slot"},
  {Name = "Trinket0Slot"},
  {Name = "Trinket1Slot"},

  {Name = "MainHandSlot"},
  {Name = "SecondaryHandSlot"},
  {Name = "ShirtSlot"},
  {Name = "TabardSlot"},
--  {Name = "Remove"},
};

local ItemStringMatch = "(item[%-%d:]+)";

function DebugMsg(msg)
  if BaudGear_Debug then
    DEFAULT_CHAT_FRAME:AddMessage(msg);
  end
end


function BaudGear_OnLoad()
  this:RegisterForDrag("LeftButton");

  this:RegisterEvent("VARIABLES_LOADED");
  this:RegisterEvent("PLAYER_LOGIN");
  this:RegisterEvent("BAG_UPDATE");
  this:RegisterEvent("UNIT_INVENTORY_CHANGED");

  tinsert(UISpecialFrames,this:GetName());
  SlashCmdList["BaudGear"] = function() BaudGearFrame:Show(); end
  SLASH_BaudGear1 = "/baudgear";
  SLASH_BaudGearMenuName = "Baud Gear";

  BaudGearVersionText:SetText("Version "..GetAddOnMetadata("BaudGear","Version"));
  DEFAULT_CHAT_FRAME:AddMessage("Baud Gear: AddOn loaded. Type /baudgear for options.");
end


function BaudGearScrollBox_OnLoad()
  this.Entries = 10;
  for Index = 1, this.Entries do
    CreateFrame("Button",this:GetName().."Entry"..Index,this,"BaudGearEntryTemplate"):SetPoint("TOP",0,6-16*Index);
  end
end


function BaudGear_OnShow()
  this:ClearAllPoints();
  this:SetPoint("CENTER");
  BaudGearUpdateSlots();
  BaudGearScrollBar_Update(BaudGearScrollBox);
end


function BaudGear_OnEvent()
  if(event=="VARIABLES_LOADED")then
    if(type(BaudGear_Cfg)~="table")then
      BaudGear_Cfg = {};
    end
    if(type(BaudGear_Cfg.Sets)~="table")then
      BaudGear_Cfg.Sets = {};
    end

  elseif(event=="PLAYER_LOGIN")then
    local Button, CheckRelic;
    for Key, Value in pairs(EquipSlot)do
      Button = CreateFrame("Button","BaudGearSlot"..Key,BaudGearSetData,"BaudGearItemButtonTemplate");
      if(Value.Name=="Remove")then
        Button.SlotText = "Drag this icon onto other slots to make Baud Gear remove the item when the set is equipped.";
      else
        Value.Slot, Value.Texture, CheckRelic = GetInventorySlotInfo(Value.Name);
        Button:SetID(Value.Slot);
        if CheckRelic and UnitHasRelicSlot("player")then
          Button.SlotText = RELICSLOT;
          Value.Texture = "Interface\\Paperdoll\\UI-PaperDoll-Slot-Relic.blp";
        else
          Button.SlotText = getglobal(strupper(Value.Name));
        end
        Value.Button = Button;
      end
      Button:SetPoint("TOPRIGHT",((Key-1)%5)*41-190,floor((Key-1)/5)*-41-60);
      Button:RegisterForDrag("LeftButton");
      Button:RegisterForClicks("LeftButtonUp");
    end

  elseif(event=="BAG_UPDATE")or(event=="UNIT_INVENTORY_CHANGED")then
    BaudGearUpdateSlots();
  end
end


function BaudGearScrollBar_Update(Frame)
  local Index, Button, ButtonText, Text;

  if not Frame then
    Frame = this:GetParent();
  end
  local FrameName = Frame:GetName();
  local ScrollBar = getglobal(FrameName.."ScrollBar");
  local Highlight = getglobal(FrameName.."Highlight");
  local Total = #BaudGear_Cfg.Sets;
  FauxScrollFrame_Update(ScrollBar,Total,Frame.Entries,16);
  Highlight:Hide();
  for Line = 1, Frame.Entries do
    Index = Line + FauxScrollFrame_GetOffset(ScrollBar);
    Button = getglobal(FrameName.."Entry"..Line);
    ButtonText = getglobal(FrameName.."Entry"..Line.."Text");
    if(Index <= Total)then
      Button:SetID(Index);
      ButtonText:SetText(BaudGear_Cfg.Sets[Index].Name);
      Button:Enable();
      Button:Show();
      if(Index==SelectedSet)then
        Highlight:SetPoint("TOP",Button);
        Highlight:Show();
      end
    else
      Button:Hide();
    end
  end

  if SelectedSet and(SelectedSet > 1)then
    BaudGearMoveUpButton:Enable();
  else
    BaudGearMoveUpButton:Disable();
  end
  if SelectedSet and(SelectedSet < Total)then
    BaudGearMoveDownButton:Enable();
  else
    BaudGearMoveDownButton:Disable();
  end
  if SelectedSet then
    BaudGearDeleteButton:Enable();
  else
    BaudGearDeleteButton:Disable();
  end
end


function BaudGearMoveButton_OnClick(Offset)
  if not SelectedSet or not BaudGear_Cfg.Sets[SelectedSet + Offset]then
    return;
  end
  BaudGear_Cfg.Sets[SelectedSet], BaudGear_Cfg.Sets[SelectedSet + Offset] =
    BaudGear_Cfg.Sets[SelectedSet + Offset], BaudGear_Cfg.Sets[SelectedSet];
  SelectedSet = SelectedSet + Offset;
  BaudGearScrollBar_Update(BaudGearScrollBox);
end


function BaudGearNewSet()
  tinsert(BaudGear_Cfg.Sets,{Name="New Set",Slot={}});
  BaudGearSelectSet(getn(BaudGear_Cfg.Sets));
end


function BaudGearDeleteSet()
  if not SelectedSet then
    return;
  end
  tremove(BaudGear_Cfg.Sets,SelectedSet);
  BaudGearSelectSet(nil);
end


function BaudGearSelectSet(Index)
  SelectedSet = Index;
  if SelectedSet then
    BaudGearUpdateSlots();
    BaudGearEditBox:SetText(BaudGear_Cfg.Sets[SelectedSet].Name);
    BaudGearSetData:Show();
    BaudGearNoDataText:Hide();
    BaudGearDeleteButton:Enable();
  else
    BaudGearSetData:Hide();
    BaudGearNoDataText:Show();
    BaudGearDeleteButton:Disable();
    BaudGearMoveUpButton:Enable();
  end
  BaudGearScrollBar_Update(BaudGearScrollBox);
end


function BaudGearEditBox_OnTextChanged()
  BaudGear_Cfg.Sets[SelectedSet].Name = this:GetText();
  BaudGearScrollBar_Update(BaudGearScrollBox);
end


function BaudGearEntry_OnClick()
  BaudGearSelectSet(this:GetID());
end


function BaudGear_ItemButton_OnEvent()
end


function BaudGearUpdateSlots()
  if not BaudGearFrame:IsShown()or not SelectedSet then
    return;
  end
  local Set = BaudGear_Cfg.Sets[SelectedSet].Slot;
  local Found = {};
  local ItemString;
  for Bag = 0, 3 do
    for Slot = 1, GetContainerNumSlots(Bag)do
      ItemString = string.match(GetContainerItemLink(Bag, Slot) or "", ItemStringMatch);
      if ItemString then
        for Key, Value in ipairs(EquipSlot)do
          if(ItemString==Set[Value.Slot])then
            Found[Value.Slot] = true;
          end
        end
      end
    end
  end

  local Button, Border, Quality, Texture, Remove;
  for Key, Value in pairs(EquipSlot)do
    Button = Value.Button;
    Border = getglobal(Button:GetName().."Border");
    Remove = getglobal(Button:GetName().."Remove");
    if not Value.Slot or(Set[Value.Slot]==true)then
      getglobal(Button:GetName().."NormalTexture"):SetColor(0, 0, 0);
      Border:Hide();
      Remove:Show();

    elseif(type(Set[Value.Slot])=="string")then
      _, _, Quality, _, _, _, _, _, _, Texture = GetItemInfo(Set[Value.Slot]);
      if not Texture then
        Texture = "Interface\\Icons\\INV_Misc_QuestionMark";
      end
      SetItemButtonTexture(Value.Button, Texture);
      if Quality and(Quality > 1)then
        Border:SetVertexColor(GetItemQualityColor(Quality));
        Border:Show();
      else
        Border:Hide();
      end
      if(string.match(GetInventoryItemLink("player", Value.Slot)or "", ItemStringMatch)==Set[Value.Slot])then
        SetItemButtonTextureVertexColor(Value.Button, 0.2, 1, 0.2);
      elseif Found[Value.Slot]then
        SetItemButtonTextureVertexColor(Value.Button, 1, 1, 1);
      else
        SetItemButtonTextureVertexColor(Value.Button, 1, 0.2, 0.2);
      end
      Remove:Hide();
    else
      SetItemButtonTexture(Value.Button, Value.Texture);
      SetItemButtonTextureVertexColor(Value.Button, 1, 1, 1);
      Border:Hide();
      Remove:Hide();
    end
  end
end


function BaudGear_ItemButton_OnEnter()
  GameTooltip:SetOwner(this, "ANCHOR_RIGHT");
  if SelectedSet then
    local ItemString = BaudGear_Cfg.Sets[SelectedSet].Slot[this:GetID()];
    if(type(ItemString)=="string")and GetItemInfo(ItemString)then
      GameTooltip:SetHyperlink(ItemString);
      return;
    end
  end
  GameTooltip:SetText(this.SlotText);
end


local function PickupItem(ItemString)
  for Key, Value in pairs(EquipSlot)do
    if strfind(GetInventoryItemLink("player",Value.Slot) or "", ItemString, 1, true)then
      PickupInventoryItem(Value.Slot);
      return;
    end
  end
  for Bag = 0, 4 do
    for Slot = 1, GetContainerNumSlots(Bag) do
      if strfind(GetContainerItemLink(Bag,Slot) or "", ItemString, 1, true)then
        PickupContainerItem(Bag, Slot);
        return;
      end
    end
  end
end


function BaudGear_ItemButton_OnClick()
  local Slot = this:GetID();
  local ItemString;
  if CursorHasItem()then
    ItemString = string.match(select(3,GetCursorInfo())or "",ItemStringMatch);
    if not ItemString then
      return;
    end
    if not CursorCanGoInSlot(Slot)then
      Slot = nil;
      for Key, Value in pairs(EquipSlot)do
        if CursorCanGoInSlot(Value.Slot)then
          Slot = Value.Slot;
          break;
        end
      end
      if not Slot then
        return;
      end
    end
    ClearCursor();
    if BaudGear_Cfg.Sets[SelectedSet].Slot[Slot]then
      PickupItem(BaudGear_Cfg.Sets[SelectedSet].Slot[Slot]);
    end
    BaudGear_Cfg.Sets[SelectedSet].Slot[Slot] = ItemString;

  elseif BaudGear_Cfg.Sets[SelectedSet].Slot[Slot]then
    PickupItem(BaudGear_Cfg.Sets[SelectedSet].Slot[Slot]);
    BaudGear_Cfg.Sets[SelectedSet].Slot[Slot] = nil;
  end
  BaudGearUpdateSlots();
end


function BaudGearEquipSet(Index)
  local ToEquip = BaudGear_Cfg.Sets[Index].Slot;
  local SkipList = {};
  local Already, Equipped, Missing, Broken = 0, 0, 0, 0;

  for Slot, Value in pairs(ToEquip) do
    if Value then
      if(string.match(GetInventoryItemLink("player",Slot)or"",ItemStringMatch) == Value)then
        Already = Already + 1;
        SkipList[Slot] = true;
      else
        Missing = Missing + 1;
      end
    end
  end
  local InfoText, OffHandBag, OffHandSlot, Link, ItemString;
  for Bag = 0, 4 do
    for BagSlot = 1, GetContainerNumSlots(Bag) do
      Link = GetContainerItemLink(Bag,BagSlot);
      ItemString = string.match(Link or"", ItemStringMatch);
      if ItemString then
        for Slot, Value in pairs(ToEquip)do
          if not SkipList[Slot]and(ItemString==Value)then
            SkipList[Slot] = true;
            Missing = Missing - 1;
            BaudGear_Tooltip:SetBagItem(Bag,BagSlot);
            local IsBroken;
            for Line = 2, BaudGear_Tooltip:NumLines()do
              if strfind(getglobal("BaudGear_TooltipTextLeft"..Line):GetText() or "","^Durability 0 ")then
                if not InfoText then
                  InfoText = "Broken Items:";
                end
                InfoText = InfoText.."\n"..Link;
                Broken = Broken + 1;
                IsBroken = true;
                break;
              end
            end
            if not IsBroken then
              Equipped = Equipped + 1;
              if(Slot==17)then
                OffHandBag, OffHandSlot = Bag, BagSlot;
              else
                ClearCursor();
                PickupContainerItem(Bag, BagSlot);
                EquipCursorItem(Slot);
              end
            end
            break;
          end
        end
      end
    end
  end

  --Off hand item is equipped last, or equipping won't work when switching from 2h
  if OffHandBag then
    ClearCursor();
    PickupContainerItem(OffHandBag, OffHandSlot);
    EquipCursorItem(17);
  end

  local Found;
  for Slot, Value in pairs(ToEquip)do
    if not SkipList[Slot]then
      if not Found then
        Found = true;
        if InfoText then
          InfoText = InfoText.."\n\n";
        else
          InfoText = "";
        end
        InfoText = InfoText.."Missing Items:";
      end
      InfoText = InfoText.."\n"..select(2,GetItemInfo(Value));
    end
  end

  BaudGearInfoTooltip.Text = InfoText;

  local Text = "BaudGear: ";
  if(Equipped == 0)then
    Text = Text.."No items to equip.";
  else
    Text = Text.."Equipping "..Equipped.." items.";
  end
  if(Already + Missing + Broken > 0)then
    Text = Text.." (";
    if(Already > 0)then
      Text = Text..Already.." already worn";
    end
    if(Missing + Broken > 0)then
      if(Already > 0)then
        Text = Text..", ";
      end
      Text = Text.."|cffff8800|Hplayer::BaudGearLink|h[";
      if(Missing > 0)then
        Text = Text..Missing.." not found";
      end
      if(Broken > 0)then
        if(Missing > 0)then
          Text = Text..", ";
        end
        Text = Text..Broken.." broken";
      end
      Text = Text.."]|h|r";
    end
    Text = Text..")";
  end
  DEFAULT_CHAT_FRAME:AddMessage(Text,1,1,0);
end

--Link format: |cff9d9d9d|Hitem:7073:0:0:0:0:0:0:0|h[Broken Fang]|h|r

hooksecurefunc("ChatFrame_OnHyperlinkShow", function(Link)
  if(Link=="player::BaudGearLink")then
    if BaudGearInfoTooltip:IsShown()then
      BaudGearInfoTooltip:Hide();
    elseif BaudGearInfoTooltip.Text then
      BaudGearInfoTooltip:SetOwner(UIParent, "ANCHOR_PRESERVE");
      BaudGearInfoTooltip:AddLine("Baud Gear Skipped");
      BaudGearInfoTooltip:AddLine(BaudGearInfoTooltip.Text,1,1,1);
      BaudGearInfoTooltip:Show();
    end
  end
end);

function BaudGearDropDown_OnLoad()
  UIDropDownMenu_Initialize(this,BaudGearDropDown_Initialize, "MENU");
  UIDropDownMenu_SetAnchor(0, 0, this, "TOPRIGHT", this:GetParent(), "BOTTOMRIGHT")
end

function BaudGearDropDown_Initialize()
  if BaudGear_Cfg and BaudGear_Cfg.Sets then
    for Index, Value in pairs(BaudGear_Cfg.Sets)do
      UIDropDownMenu_AddButton({text=Value.Name,func=BaudGearEquipSet,arg1=Index,notCheckable=1});
    end
  end
  UIDropDownMenu_AddButton({text="Edit Sets...",func=function() BaudGearFrame:Show();end,notCheckable=1});
end


function BaudGearMinimapButton_OnLoad()
  this:RegisterForClicks("LeftButtonUp", "RightButtonUp");
  this:RegisterForDrag("LeftButton");
  this:SetFrameLevel(this:GetFrameLevel()+1);
end


function BaudGearMinimapButton_OnClick()
  PlaySound("UChatScrollButton");
  ToggleDropDownMenu(1, nil, BaudGearDropDown);
end


function BaudGearMinimapButton_OnEnter()
  if this.Dragging then
    return;
  end
  GameTooltip:SetOwner(this, "ANCHOR_TOPRIGHT");
  GameTooltip:AddLine("Baud Gear");
  GameTooltip:AddLine("Click to select a gear set.",1,1,1);
  GameTooltip:AddLine("Shift-drag to move button.",1,1,1);
  GameTooltip:Show();
end


function BaudGearMinimapButton_OnLeave()
  GameTooltip:Hide();
end


function BaudGearMinimapButton_OnDragStart()
  if IsShiftKeyDown()then
    this.Dragging = true;
    BaudGearMinimapButton_OnLeave();
  end
end


function BaudGearMinimapButton_OnDragStop()
  this:StopMovingOrSizing();
  this.Dragging = nil;
  this.Moving = nil;
end


function BaudGearMinimapButton_OnUpdate()
  if not this.Dragging then
    return;
  end
  local MapScale = Minimap:GetEffectiveScale();
  local CX, CY = GetCursorPosition();
  local X, Y = (Minimap:GetRight() - 70) * MapScale, (Minimap:GetTop() - 70) * MapScale;
  local Dist = sqrt(math.pow(X - CX, 2) + math.pow(Y - CY, 2)) / MapScale;
  local Scale = this:GetEffectiveScale();
  if(Dist <= 90)then
    if this.Moving then
      this:StopMovingOrSizing();
      this.Moving = nil;
    end
    local Angle = atan2(CY - Y, X - CX) - 90;
    this:ClearAllPoints();
    this:SetPoint("CENTER", Minimap, "TOPRIGHT", (sin(Angle) * 80 - 70) * MapScale / Scale, (cos(Angle) * 77 - 73) * MapScale / Scale);

  elseif not this.Moving then
    this:ClearAllPoints();
    this:SetPoint("CENTER", UIParent, "BOTTOMLEFT",CX / Scale, CY / Scale);
    this:StartMoving();
    this.Moving = true;
  end
end
