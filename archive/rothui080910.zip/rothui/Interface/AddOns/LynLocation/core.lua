local addon = CreateFrame("Frame", nil, UIParent)
-- frame
local frame_anchor = "BOTTOM"
local frame_x = 0
local frame_y = -35
-- font
local font = "Fonts\\ARIALN.TTF"
local size = 12
local color = { r=0.4, g=0.4, b=0.4 }
local text_anchor = "BOTTOM"
-- used locals
local x, y, text, zone
-- new
function addon:new()
	-- frame position
	self:SetPoint(frame_anchor, Minimap, frame_anchor, frame_x, frame_y)
	self:SetWidth(50)
	self:SetHeight(12)
	-- create fontstring
	text = self:CreateFontString(nil, "OVERLAY")
	-- text style
	text:SetFont(font, size, "THINOUTLINE")
	text:SetTextColor(color.r, color.g, color.b)
	--text:SetShadowOffset(1, -1)
	text:SetPoint(text_anchor, self)
	text:SetShadowColor(1,1,1,0)
	
	self:RegisterEvent("ZONE_CHANGED_NEW_AREA")
	
	-- update
	self:SetScript("OnUpdate", self.update) 
	self:SetScript("OnEvent", self.event)
end
function addon:event()
	if (event == "ZONE_CHANGED_NEW_AREA") then 
		SetMapToCurrentZone()
	end
end
-- update function
function addon:update()
	-- get zone map
	zone = GetMinimapZoneText()
	zone = zone.."|r"
	-- get player x,y
	x, y = GetPlayerMapPosition("player")
	-- if x and y 0 then boo
	if(x == 0 and y == 0) then
		coords = "";
	else
		coords = "  "..format("%.2d | %.2d",x*100,y*100)
	end
	-- set it
	text:SetText(zone..coords) 
end
-- fire
addon:new()