
function PetPopup_Confirm() 
	StaticPopup_Show("PETRENAMECONFIRM");
end

function PetPopup_Cancel()
	PetRenamePopup:Hide();
end
