


function LocalizePost()
	-- Put all locale specific string adjustments here
end
