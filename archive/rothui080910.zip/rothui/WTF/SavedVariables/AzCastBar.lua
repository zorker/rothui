
AzCastBar_Config = {
	["Player"] = {
		["fontFace"] = "Fonts\\FRIZQT__.TTF",
		["left"] = 536.177001953125,
		["colSafezone"] = {
			0.3, -- [1]
			0.8, -- [2]
			0.3, -- [3]
			0.6, -- [4]
		},
		["colInterrupt"] = {
			0.203921568627451, -- [1]
			0, -- [2]
			0, -- [3]
			1, -- [4]
		},
		["colNormal"] = {
			0.1254901960784314, -- [1]
			0.1411764705882353, -- [2]
			0.1254901960784314, -- [3]
			1, -- [4]
		},
		["colBackdrop"] = {
			0, -- [1]
			0, -- [2]
			0, -- [3]
			1, -- [4]
		},
		["fontFlags"] = "THINOUTLINE",
		["enabled"] = true,
		["backdropIndent"] = -1.5,
		["texture"] = "Interface\\Addons\\rTextures\\statusbar",
		["bottom"] = 187.36865234375,
		["fontSize"] = 13,
		["fadeTime"] = 0.6,
		["showRank"] = false,
		["width"] = 280,
		["alpha"] = 1,
		["backdropBG"] = "Interface\\Tooltips\\UI-Tooltip-Background",
		["colFailed"] = {
			0.2156862745098039, -- [1]
			0, -- [2]
			0.0196078431372549, -- [3]
			1, -- [4]
		},
		["showIcon"] = true,
		["height"] = 20,
		["safeZone"] = true,
		["colFont"] = {
			0.9764705882352941, -- [1]
			1, -- [2]
			0.9647058823529412, -- [3]
			1, -- [4]
		},
		["colBackground"] = {
			1, -- [1]
			1, -- [2]
			1, -- [3]
			1, -- [4]
		},
	},
	["optionsLeft"] = 880.8826293945313,
	["Focus"] = {
		["fontFace"] = "Fonts\\FRIZQT__.TTF",
		["left"] = 57.11111831665039,
		["colInterrupt"] = {
			1, -- [1]
			0.75, -- [2]
			0.5, -- [3]
			1, -- [4]
		},
		["colNormal"] = {
			0.4, -- [1]
			0.6, -- [2]
			0.8, -- [3]
			1, -- [4]
		},
		["colBackdrop"] = {
			0.1, -- [1]
			0.22, -- [2]
			0.35, -- [3]
			1, -- [4]
		},
		["fontFlags"] = "",
		["enabled"] = false,
		["backdropIndent"] = -3,
		["bottom"] = 459.7778930664063,
		["texture"] = "Interface\\Addons\\rTextures\\statusbar",
		["fadeTime"] = 0.6,
		["alpha"] = 1,
		["width"] = 300,
		["fontSize"] = 12,
		["showRank"] = false,
		["colFailed"] = {
			1, -- [1]
			0.5, -- [2]
			0.5, -- [3]
			1, -- [4]
		},
		["backdropBG"] = "Interface\\Tooltips\\UI-Tooltip-Background",
		["height"] = 20,
		["showIcon"] = false,
		["colFont"] = {
			1, -- [1]
			1, -- [2]
			1, -- [3]
			1, -- [4]
		},
		["colBackground"] = {
			1, -- [1]
			1, -- [2]
			1, -- [3]
			1, -- [4]
		},
	},
	["Target"] = {
		["fontFace"] = "Fonts\\FRIZQT__.TTF",
		["left"] = 516.3081665039063,
		["colInterrupt"] = {
			1, -- [1]
			0.75, -- [2]
			0.5, -- [3]
			1, -- [4]
		},
		["colNormal"] = {
			0.09803921568627451, -- [1]
			0.1058823529411765, -- [2]
			0.09803921568627451, -- [3]
			1, -- [4]
		},
		["colBackdrop"] = {
			0.1, -- [1]
			0.22, -- [2]
			0.35, -- [3]
			1, -- [4]
		},
		["fontFlags"] = "THINOUTLINE",
		["enabled"] = true,
		["backdropIndent"] = -2,
		["bottom"] = 370.7488098144531,
		["texture"] = "Interface\\Addons\\rTextures\\statusbar",
		["fadeTime"] = 0.6,
		["alpha"] = 1,
		["width"] = 316,
		["fontSize"] = 15,
		["showRank"] = false,
		["colFailed"] = {
			1, -- [1]
			0.5, -- [2]
			0.5, -- [3]
			1, -- [4]
		},
		["backdropBG"] = "Interface\\Tooltips\\UI-Tooltip-Background",
		["height"] = 24,
		["showIcon"] = true,
		["colFont"] = {
			1, -- [1]
			1, -- [2]
			1, -- [3]
			1, -- [4]
		},
		["colBackground"] = {
			1, -- [1]
			1, -- [2]
			1, -- [3]
			1, -- [4]
		},
	},
	["optionsBottom"] = 351.2699279785156,
	["Mirror"] = {
		["fontSize"] = 12,
		["left"] = 572.5618286132813,
		["colNormal"] = {
			0.4, -- [1]
			0.6, -- [2]
			0.8, -- [3]
			1, -- [4]
		},
		["colBackdrop"] = {
			0.1, -- [1]
			0.22, -- [2]
			0.35, -- [3]
			1, -- [4]
		},
		["fontFlags"] = "",
		["enabled"] = true,
		["backdropIndent"] = -2,
		["bottom"] = 625.4825439453125,
		["fadeTime"] = 0.6,
		["alpha"] = 1,
		["width"] = 215,
		["texture"] = "Interface\\Addons\\rTextures\\statusbar",
		["fontFace"] = "Fonts\\FRIZQT__.TTF",
		["showIcon"] = true,
		["height"] = 18,
		["backdropBG"] = "Interface\\Tooltips\\UI-Tooltip-Background",
		["colFont"] = {
			1, -- [1]
			1, -- [2]
			1, -- [3]
			1, -- [4]
		},
		["colBackground"] = {
			1, -- [1]
			1, -- [2]
			1, -- [3]
			1, -- [4]
		},
	},
	["Pet"] = {
		["fontFace"] = "Fonts\\FRIZQT__.TTF",
		["left"] = 58,
		["colInterrupt"] = {
			1, -- [1]
			0.75, -- [2]
			0.5, -- [3]
			1, -- [4]
		},
		["colNormal"] = {
			0.4, -- [1]
			0.6, -- [2]
			0.8, -- [3]
			1, -- [4]
		},
		["colBackdrop"] = {
			0.1, -- [1]
			0.22, -- [2]
			0.35, -- [3]
			1, -- [4]
		},
		["fontFlags"] = "",
		["enabled"] = false,
		["backdropIndent"] = -3,
		["bottom"] = 421.111083984375,
		["texture"] = "Interface\\Addons\\rTextures\\statusbar",
		["fadeTime"] = 0.6,
		["alpha"] = 1,
		["width"] = 300,
		["fontSize"] = 12,
		["showRank"] = false,
		["colFailed"] = {
			1, -- [1]
			0.5, -- [2]
			0.5, -- [3]
			1, -- [4]
		},
		["backdropBG"] = "Interface\\Tooltips\\UI-Tooltip-Background",
		["height"] = 20,
		["showIcon"] = false,
		["colFont"] = {
			1, -- [1]
			1, -- [2]
			1, -- [3]
			1, -- [4]
		},
		["colBackground"] = {
			1, -- [1]
			1, -- [2]
			1, -- [3]
			1, -- [4]
		},
	},
}
