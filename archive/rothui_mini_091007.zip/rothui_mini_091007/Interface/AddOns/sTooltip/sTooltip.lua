--[[
	
	sTooltip
	Copyright (c) 2008, Shantalya
	All rights reserved.
	
]]

--[[ KONFIGURATION - START ]]--

local myscale = 0.86

local barHeight = 7; -- Die H�he der Lebensleiste
local barHealthText = false; -- Lebensanzeige auf der Lebensleiste || true = Ja, false = Nein

local textSize = 12; -- Schriftgr��e der Lebensleiste
local textFont = "Interface\\AddOns\\oUF_D3Orbs\\avqest.ttf"; -- Schriftart der Lebensleiste

local statusBarTexture = "Interface\\TargetingFrame\\UI-StatusBar"; -- Textur der Lebensleiste

local edgef = "Interface\\Tooltips\\UI-Tooltip-Border"
--local edgef = nil
local bgfile = "Interface\\Tooltips\\UI-Tooltip-Background"
--local bgfile = nil
local backd_alpha = 0.9

--[[ KONFIGURATION - ENDE ]]--


old_HealthBar_OnValueChanged = HealthBar_OnValueChanged;
function HealthBar_OnValueChanged(self, value, smooth)
	if ( not value ) then
		return;
	end
	if ( GameTooltipStatusBar and barHealthText ) then
		if ( not GameTooltipStatusBar.HealthText ) then
			GameTooltipStatusBar.HealthText = GameTooltipStatusBar:CreateFontString("GameTooltipStatusBarHealthText", "ARTWORK");
			GameTooltipStatusBar.HealthText:SetFont(textFont, textSize);
			GameTooltipStatusBar.HealthText:SetShadowOffset( 1, -1);
			GameTooltipStatusBar.HealthText:SetPoint("CENTER", GameTooltipStatusBar, "CENTER", 0, 1);
		end
		GameTooltipStatusBar.HealthText:SetText("");
		local unit = select(2, GameTooltip:GetUnit());	
		if ( unit and UnitName(unit) ~= UNKNOWN ) then
			if ( UnitHealth(unit) > 0 ) then
				GameTooltipStatusBar.HealthText:SetText(UnitHealth(unit));
			else
				GameTooltipStatusBar.HealthText:SetText(DEAD);
			end
		end
	end
end

function GameTooltip:GetReputation(fraction)
	if ( fraction >= -42000 and fraction < -6000) then
		return (fraction+42000).. "/36000";
	elseif ( fraction >= -6000 and fraction < -3000) then
		return (fraction+6000).. "/3000";
	elseif ( fraction >= -3000 and fraction < 0) then
		return (fraction+3000).. "/3000";
	elseif ( fraction >= 0 and fraction < 3000) then
		return fraction .. "/3000";
	elseif ( fraction >= 3000 and fraction < 9000 ) then
		return (fraction-3000) .. "/6000";
	elseif(  fraction >= 9000 and fraction < 21000 ) then
		return (fraction-9000) .. "/12000";
	elseif ( fraction >= 21000 and fraction < 42000 ) then
		return (fraction-21000) .. "/21000";
	elseif ( fraction >= 42000 ) then
		return (fraction-42000) .. "/1000";
	else
		return "Unbekannter Ruf";
	end
end

GameTooltip:HookScript("OnTooltipSetUnit", function(self)
	local unit = select(2, self:GetUnit());	
	
	if ( unit and UnitName(unit) ~= UNKNOWN ) then
		local unitIsPlayer = UnitIsPlayer(unit);
		local unitClassColor = rRAID_CLASS_COLORS[select(2,UnitClass(unit))] or { r = 1, g = 0, b = 1 };
		local unitLevel = UnitLevel(unit);
		local unitClassification = UnitClassification(unit);
		local unitName = UnitName(unit);
		local unitReactionColor = { r = select(1, UnitSelectionColor(unit)), g = select(2, UnitSelectionColor(unit)), b = select(3, UnitSelectionColor(unit)) };
		local isInInstance = select(2, IsInInstance());
		local difficultyColor
		if GetQuestDifficultyColor then
		  difficultyColor = GetQuestDifficultyColor(unitLevel);
		else
		  difficultyColor = GetDifficultyColor(unitLevel);
		end
		local unitTargetName = UnitName(unit .. "target");
		local unitTargetClassColor = rRAID_CLASS_COLORS[select(2,UnitClass(unit .. "target"))] or { r = 1, g = 0, b = 1 };
		local unitTargetReactionColor = { r = select(1, UnitSelectionColor(unit .. "target")), g = select(2, UnitSelectionColor(unit .. "target")), b = select(3, UnitSelectionColor(unit .. "target")) };
		
		if ( UnitLevel(unit) == -1 ) then
			unitLevel = "|cffff0000??|r";
		end
		
		
		if ( unitIsPlayer ) then
			--if ( IsInGuild() and GameTooltipTextLeft2:GetText():find("^" .. GetGuildInfo("player")) ) then
				--GameTooltipTextLeft2:SetTextColor(1, 0, 1);
			--end
			
		if ( GetGuildInfo(unit) ) then
      GameTooltipTextLeft2:SetTextColor(0.2, 1, 0.2);
			for i=2, GameTooltip:NumLines(), 1 do
				if ( getglobal("GameTooltipTextLeft" .. i):GetText():find("^" .. GetGuildInfo(unit)) ) then
					getglobal("GameTooltipTextLeft" .. i):SetText("<" .. getglobal("GameTooltipTextLeft" .. i):GetText() .. ">");
					break;
				end
			end
		
	 else
			
			for i=2, GameTooltip:NumLines(), 1 do
				if ( getglobal("GameTooltipTextLeft" .. i):GetText():find("^" .. LEVEL) ) then
					getglobal("GameTooltipTextLeft" .. i):SetText(format("|cff%02x%02x%02x%s|r", difficultyColor.r*255, difficultyColor.g*255, difficultyColor.b*255, unitLevel) .. " " .. UnitRace(unit) .. ", " .. format("|cff%02x%02x%02x%s|r", unitClassColor.r*255, unitClassColor.g*255, unitClassColor.b*255, UnitClass(unit)));
					break;
				end
			end
			
	  end
			
			--self:SetBackdropBorderColor(unitClassColor.r, unitClassColor.g, unitClassColor.b);
			--self:SetBackdropBorderColor(0.4, 0.4, 0.4);
			GameTooltipStatusBar:SetStatusBarColor(unitClassColor.r, unitClassColor.g, unitClassColor.b);
			GameTooltipTextLeft1:SetTextColor(unitClassColor.r, unitClassColor.g, unitClassColor.b);
		else
			if ( unitClassification == "worldboss" ) then
				unitClassification = " (" .. BOSS .. ") ";
			elseif ( unitClassification == "rareelite" ) then
				unitClassification = " (Rare Elite) ";
			elseif ( unitClassification == "elite" ) then
				unitClassification = " (" .. ELITE .. ") ";
			elseif ( unitClassification == "rare" ) then
				unitClassification = " (Rare) ";
			else
				unitClassification = " ";
			end
			
			for i=2, GameTooltip:NumLines(), 1 do
				if ( getglobal("GameTooltipTextLeft" .. i):GetText():find("^" .. LEVEL) ) then
					getglobal("GameTooltipTextLeft" .. i):SetText(format("|cff%02x%02x%02x%s|r", difficultyColor.r*255, difficultyColor.g*255, difficultyColor.b*255, unitLevel) .. unitClassification .. UnitCreatureType(unit));
					break;
				end
			end
			
			for i=3, GameTooltip:NumLines(), 1 do
				for factionIndex=1, GetNumFactions(), 1 do
					name, _, _, _, _, earnedValue, _, _, isHeader = GetFactionInfo(factionIndex);
					if ( not isHeader and getglobal("GameTooltipTextLeft" .. i):GetText():find("^" .. name) ) then
						getglobal("GameTooltipTextLeft" .. i):SetText(getglobal("GameTooltipTextLeft" .. i):GetText() .. " (" .. self:GetReputation(earnedValue) .. ")");
						break;
					end
				end
			end
			
			if ( UnitIsTapped(unit) and not UnitIsTappedByPlayer(unit) ) then
				--self:SetBackdropBorderColor(0.5, 0.5, 0.5);
				self:SetBackdropBorderColor(0.4, 0.4, 0.4);
				GameTooltipStatusBar:SetStatusBarColor(0.5, 0.5, 0.5);
				GameTooltipTextLeft1:SetTextColor(0.5, 0.5, 0.5);
			else
				--self:SetBackdropBorderColor(unitReactionColor.r, unitReactionColor.g, unitReactionColor.b);
				self:SetBackdropBorderColor(0.4, 0.4, 0.4);
				GameTooltipStatusBar:SetStatusBarColor(unitReactionColor.r, unitReactionColor.g, unitReactionColor.b);
				GameTooltipTextLeft1:SetTextColor(unitReactionColor.r, unitReactionColor.g, unitReactionColor.b);
			end
		end		
		
		if ( UnitExists(unit .. "target") ) then
			if ( UnitName("player") == unitTargetName ) then
				self:AddLine(TARGET .. ": |cffff00ff" .. string.upper(YOU) .. "|r", 1, 1, 1)
			else
				if UnitIsPlayer(unit .. "target") then
					self:AddLine(TARGET .. ": " .. format("|cff%02x%02x%02x%s|r", unitTargetClassColor.r*255, unitTargetClassColor.g*255, unitTargetClassColor.b*255, unitTargetName), 1, 1, 1)
				else
					self:AddLine(TARGET .. ": " .. format("|cff%02x%02x%02x%s|r", unitTargetReactionColor.r*255, unitTargetReactionColor.g*255, unitTargetReactionColor.b*255, unitTargetName), 1, 1, 1)
				end
			end
		end
		if ( UnitIsPVP(unit) and isInInstance ~= "pvp" and isInInstance ~= "arena" and GetZonePVPInfo() ~= "combat" ) then
			GameTooltipTextLeft1:SetText("|cffFF8800#|r " .. GameTooltipTextLeft1:GetText());
		end
		for i=2, GameTooltip:NumLines(), 1 do
			if ( getglobal("GameTooltipTextLeft" .. i):GetText():find(PVP_ENABLED) ) then
				getglobal("GameTooltipTextLeft" .. i):SetText(nil);
				break
			end
		end
		
		GameTooltipStatusBar:SetStatusBarTexture(statusBarTexture)
    self:AddLine(" ")
    GameTooltipStatusBar:ClearAllPoints();
    GameTooltipStatusBar:SetPoint("BOTTOMLEFT", 8, 11);
    GameTooltipStatusBar:SetPoint("BOTTOMRIGHT", -8, 11);
    GameTooltipStatusBar:SetHeight(barHeight);
		
	end
end);

GameTooltipStatusBar.background = GameTooltipStatusBar:CreateTexture("GameTooltipStatusBarBackground", "BACKGROUND");
GameTooltipStatusBar.background:SetPoint("TOPLEFT");
GameTooltipStatusBar.background:SetPoint("BOTTOMRIGHT");
GameTooltipStatusBar.background:SetTexture(statusBarTexture);
GameTooltipStatusBar.background:SetVertexColor(0.15, 0.15, 0.15, 1);


GameTooltip:SetBackdrop({ bgFile = bgfile, edgeFile = edgef, tile = true, tileSize = 8, edgeSize = 16, insets = { left = 4, right = 4, top = 4, bottom = 4 } });
GameTooltip:SetScript("OnShow", function(self) 

  self:SetBackdropColor(0, 0, 0, backd_alpha); 

  self:SetScale(myscale)

  --[[
  local z = 1
  while _G["GameTooltipTextLeft"..z] 
  do 
    if z == 1 then
      _G["GameTooltipTextLeft"..z]:SetFont(textFont, textSize+2);
    else
      _G["GameTooltipTextLeft"..z]:SetFont(textFont, textSize);
    end
    z = z + 1 
  end

  local z = 1
  while _G["GameTooltipTextRight"..z] 
  do 
    _G["GameTooltipTextRight"..z]:SetFont(textFont, textSize);
    z = z + 1 
  end
  ]]--

end);

ItemRefTooltip:SetBackdrop({ bgFile = bgfile, edgeFile = edgef, tile = true, tileSize = 8, edgeSize = 16, insets = { left = 4, right = 4, top = 4, bottom = 4 } });
ItemRefTooltip:SetScript("OnShow", function(self) self:SetBackdropColor(0, 0, 0, backd_alpha); 

  self:SetScale(myscale)

  --[[
  local z = 1
  while _G["GameTooltipTextLeft"..z] 
  do 
    _G["GameTooltipTextLeft"..z]:SetFont(NAMEPLATE_FONT, textSize);
    z = z + 1 
  end

  local z = 1
  while _G["GameTooltipTextRight"..z] 
  do 
    _G["GameTooltipTextRight"..z]:SetFont(NAMEPLATE_FONT, textSize);
    z = z + 1 
  end
  ]]--

end);

ShoppingTooltip1:SetBackdrop({ bgFile = bgfile, edgeFile = edgef, tile = true, tileSize = 8, edgeSize = 16, insets = { left = 4, right = 4, top = 4, bottom = 4 } });
ShoppingTooltip1:SetScript("OnShow", function(self) self:SetBackdropColor(0, 0, 0, backd_alpha); end);

ShoppingTooltip2:SetBackdrop({ bgFile = bgfile, edgeFile = edgef, tile = true, tileSize = 8, edgeSize = 16, insets = { left = 4, right = 4, top = 4, bottom = 4 } });
ShoppingTooltip2:SetScript("OnShow", function(self) self:SetBackdropColor(0, 0, 0, backd_alpha); end);

ShoppingTooltip3:SetBackdrop({ bgFile = bgfile, edgeFile = edgef, tile = true, tileSize = 8, edgeSize = 16, insets = { left = 4, right = 4, top = 4, bottom = 4 } });
ShoppingTooltip3:SetScript("OnShow", function(self) self:SetBackdropColor(0, 0, 0, backd_alpha); end);

DropDownList1MenuBackdrop:SetBackdrop({ bgFile = bgfile, edgeFile = edgef, tile = true, tileSize = 8, edgeSize = 16, insets = { left = 4, right = 4, top = 4, bottom = 4 } });
DropDownList1MenuBackdrop:SetScript("OnShow", function(self) self:SetBackdropColor(0, 0, 0, backd_alpha); end);

DropDownList2MenuBackdrop:SetBackdrop({ bgFile = bgfile, edgeFile = edgef, tile = true, tileSize = 8, edgeSize = 16, insets = { left = 4, right = 4, top = 4, bottom = 4 } });
DropDownList2MenuBackdrop:SetScript("OnShow", function(self) self:SetBackdropColor(0, 0, 0, backd_alpha); end);


local frame = CreateFrame("Frame", "ItemRefTooltipIconFrame", ItemRefTooltip);
frame:SetWidth(37);
frame:SetHeight(37);
frame:SetBackdrop({ edgeFile = edgef, tile = true, tileSize = 16, edgeSize = 16, insets = { left = 4, right = 4, top = 4, bottom = 4 }});
frame:SetPoint("TOPRIGHT", ItemRefTooltip, "TOPLEFT", 2, 0);
frame.icon = frame:CreateTexture(frame:GetName() .. "IconTexture", "BACKGROUND");
frame.icon:SetWidth(33);
frame.icon:SetHeight(33);
frame.icon:SetPoint("CENTER", frame, "CENTER", 0, 0);
--frame.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93); 
frame.count = frame:CreateFontString(frame:GetName() .. "Count", "ARTWORK", "NumberFontNormal");
frame.count:SetJustifyH("RIGHT");
frame.count:SetPoint("BOTTOMRIGHT", frame.icon, -2, 2);

hooksecurefunc("SetItemRef", function(link, text, button)
	if ( ItemRefTooltipIconFrame:IsShown() ) then
		SetItemButtonCount(ItemRefTooltipIconFrame, 0);
		ItemRefTooltipIconFrame:Hide();
	end
	if ( strsub(link, 1, 4) == "item" ) then
		local itemStackCount, _, itemTexture = select(8, GetItemInfo(strmatch(link, "item:(%d+)")));
		itemStackCount = itemStackCount or 0;
		SetItemButtonTexture(ItemRefTooltipIconFrame, itemTexture);
		SetItemButtonCount(ItemRefTooltipIconFrame, itemStackCount);
		ItemRefTooltipIconFrame:Show();
	elseif ( strsub(link, 1, 5) == "spell" ) then
		SetItemButtonTexture(ItemRefTooltipIconFrame, select(3, GetSpellInfo(strmatch(link, "spell:(%d+)"))));
		ItemRefTooltipIconFrame:Show();
	elseif ( strsub(link, 1, 11) == "achievement") then
		SetItemButtonTexture(ItemRefTooltipIconFrame, select(10, GetAchievementInfo(strmatch(link, "achievement:(%d+)"))));
		ItemRefTooltipIconFrame:Show();
	end
end);


GameTooltip_SetDefaultAnchor = function(tooltip, parent)
	tooltip:SetOwner(parent, "ANCHOR_NONE");
	tooltip:SetPoint("BOTTOMRIGHT", UIParent, "BOTTOMRIGHT", -70, CONTAINER_OFFSET_Y+70);
	tooltip.default = 1;
end