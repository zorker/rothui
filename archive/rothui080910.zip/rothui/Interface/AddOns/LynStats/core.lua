--[[

	VERSION 1.4
	by Lyn
	
	CREDITS:
	evl and his awesome evl_clock to get lynstats "ace-less"
	
--]]
local addon = CreateFrame("Button", nil, UIParent)

-- the x-files aka. configuration
local frame_anchor = "TOPRIGHT" -- LEFT, TOPLEFT, TOP, TOPRIGHT, RIGHT, CENTER, BOTTOMRIGHT, BOTTOM, BOTTOMLEFT
local pos_x = -10
local pos_y = -160
local text_anchor = "BOTTOM"
local font = "Fonts\\ARIALN.TTF"
local size = 12
local classcolors = false -- true or false
local shadow = true -- true / false
local outline = false -- true / false
local time24 = true -- true: 24h / false: 12h


-- reinforcements!
local color, mail, hasmail, ticktack, lag, fps, ep, xp_cur, xp_max, text, blizz, memory, entry, i

if classcolors == true then
	color = RAID_CLASS_COLORS[select(2, UnitClass("player"))]
else
	color = { r=0.4, g=0.4, b=0.4 } -- own textcolor
end

-- format memory stuff
local memformat = function(number)
	if number > 1000 then
		return string.format("%.2f mb", (number / 1000))
	else
		return string.format("%.1f kb", floor(number))
	end
end

-- ordering
local addoncompare = function(a, b)
	return a.memory > b.memory
end

-- the allmighty
function addon:new()
	text = self:CreateFontString(nil, "OVERLAY")
	text:SetFont(font, size, "THINOUTLINE")
	--text:SetShadowOffset(1, -1)
	text:SetShadowColor(1,1,1,0)

	self:SetWidth(160)
	self:SetHeight(12)

	text:SetPoint(text_anchor, self)
	text:SetTextColor(color.r, color.g, color.b)

	--self:SetPoint(frame_anchor, UIParent, frame_anchor, pos_x, pos_y)
	
	self:SetPoint("TOP", Minimap, "BOTTOM", 0, -7)
	
	self:SetScript("OnUpdate", self.update)
	self:SetScript("OnEnter", self.enter)
	self:SetScript("OnLeave", function() GameTooltip:Hide() end)
end

-- update
local last = 0
function addon:update(elapsed)
	last = last + elapsed

	if last > 1 then
		-- mail stuff
		hasmail = (HasNewMail() or 0);
		if hasmail > 0 then
			mail = "|c00FA58F4new!|r "
		else
			mail = ""
		end
		
		-- date thingy
		if time24 == true then
			ticktack = date("%H:%M")
		else
			ticktack = date("%I:%M")
		end
		ticktack = ticktack.."|r"
		
		-- fps crap
		fps = GetFramerate()
		fps = floor(fps).."|rfps  "
		
		-- right down downright + punch
		lag = select(3, GetNetStats())
		lag = lag.."|rms  "
		
		-- xp stuff
		xp_cur = UnitXP("player")
		xp_max = UnitXPMax("player")
		if UnitLevel("player") < MAX_PLAYER_LEVEL then
			ep = floor(xp_max - xp_cur).."|rxp  "
		else
			ep = ""
		end
		
		-- reset timer
		last = 0
		
		-- the magic!
		text:SetText(fps..lag..ep..mail..ticktack)
		self:SetWidth(text:GetStringWidth())
	end
end

--[[
	ADDON LIST
--]]
function addon:enter()
	GameTooltip:SetOwner(self, "ANCHOR_NONE")
	GameTooltip:SetPoint("BOTTOMRIGHT", UIParent, "BOTTOMRIGHT", -25, 25)
	blizz = collectgarbage("count")
	addons = {}
	total = 0
	UpdateAddOnMemoryUsage()
	for i=1, GetNumAddOns(), 1 do
		if (GetAddOnMemoryUsage(i) > 0 ) then
			memory = GetAddOnMemoryUsage(i)
			entry = {name = GetAddOnInfo(i), memory = memory}
			table.insert(addons, entry)
			total = total + memory
		end
	end
	table.sort(addons, addoncompare)
	for _, entry in pairs(addons) do
		GameTooltip:AddDoubleLine(entry.name, memformat(entry.memory), 1, 1, 1, 1, 1, 1)
	end
	GameTooltip:AddLine("----------------------------------------------------------------", 1, 1, 1)
	GameTooltip:AddDoubleLine("Total", memformat(total), color.r, color.g, color.b, color.r, color.g, color.b)
	GameTooltip:AddDoubleLine("Total incl. Blizzard", memformat(blizz), color.r, color.g, color.b, color.r, color.g, color.b)
	GameTooltip:Show()
end

-- and... go!
addon:new()