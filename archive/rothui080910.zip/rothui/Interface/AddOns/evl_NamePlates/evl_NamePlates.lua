local evl_NamePlates = CreateFrame("Frame", nil, UIParent)

local texture = "Interface\\Addons\\rTextures\\statusbar"

local function IsNamePlateFrame(frame)
  if frame:GetName() then
    return false
  end
  
  local overlayRegion = frame:GetRegions()
  if not overlayRegion or overlayRegion:GetObjectType() ~= "Texture" or overlayRegion:GetTexture() ~= "Interface\\Tooltips\\Nameplate-Border" then
    return false
  end
  
  return true
end

function evl_NamePlates:new()
	self:SetScript("OnUpdate", self.onUpdate)
end

local lastUpdate = 0
local frame
function evl_NamePlates:onUpdate(elapsed)
	lastUpdate = lastUpdate + elapsed
	
	if lastUpdate > 1 then
		lastUpdate = 0

		for i = 1, select("#", WorldFrame:GetChildren()) do
			frame = select(i, WorldFrame:GetChildren())
    
			if not frame.background and IsNamePlateFrame(frame) then 
				self:setupNamePlate(frame)
			end
		end  
	end
end

local healthBar, castBar
local overlayRegion, highlightRegion, nameTextRegion, bossIconRegion, levelTextRegion, raidIconRegion
function evl_NamePlates:setupNamePlate(frame)
  healthBar, castBar = frame:GetChildren()
  overlayRegion, _, _, highlightRegion, nameTextRegion, levelTextRegion, bossIconRegion, raidIconRegion = frame:GetRegions()
  
  -- Border on top
  overlayRegion:Hide()
	
	-- Icons we don't need
	bossIconRegion:Hide()
  
  -- Name text
  nameTextRegion:ClearAllPoints()
  nameTextRegion:SetPoint("BOTTOM", healthBar, "TOP", 0, 3)
  nameTextRegion:SetFont(NAMEPLATE_FONT, 14, "THINOUTLINE")
  nameTextRegion:SetShadowColor(1,1,1,0)
  
  -- Level text
  levelTextRegion:ClearAllPoints()
  levelTextRegion:SetPoint("LEFT", healthBar, "RIGHT", 3, 0)
  levelTextRegion:SetFont(NAMEPLATE_FONT, 14, "THINOUTLINE")
  levelTextRegion:SetShadowColor(1,1,1,0)
  
  -- Highlight which shows up on mouseover
  --highlightRegion:SetHeight(12)
  --highlightRegion:SetTexture(texture)
  highlightRegion:SetAlpha(0)
  
  -- Health bar
  healthBar:SetStatusBarTexture(texture)
  healthBar:SetHeight(10)
  
  -- Background
  background = healthBar:CreateTexture(nil, "BORDER")
  --background:SetAllPoints(healthBar)
  background:SetPoint("TOPLEFT", healthBar, "TOPLEFT", -1.1, 1.1)
  background:SetPoint("BOTTOMRIGHT", healthBar, "BOTTOMRIGHT", 1.1, -1.1)
  background:SetTexture(texture)
  background:SetVertexColor(.1, .1, .1, 1)
 
  
	frame.background = background
end

evl_NamePlates:new()
