
TipTac_Config = {
	["showUnitTip"] = true,
	["showRealm"] = "show",
	["selfBuffsOnly"] = false,
	["barHeight"] = 6,
	["manaBarColor"] = {
		0.3, -- [1]
		0.55, -- [2]
		0.9, -- [3]
		1, -- [4]
	},
	["anchorPoint"] = "BOTTOMRIGHT",
	["colReactBack1"] = {
		0.2, -- [1]
		0.2, -- [2]
		0.2, -- [3]
		1, -- [4]
	},
	["backdropEdgeSize"] = 16,
	["powerBar"] = false,
	["fontFlags"] = "THINOUTLINE",
	["showAuraCooldown"] = false,
	["colReactBack7"] = {
		0.05, -- [1]
		0.05, -- [2]
		0.05, -- [3]
		1, -- [4]
	},
	["showDebuffs"] = false,
	["powerBarText"] = "value",
	["colReactText1"] = "|cffc0c0c0",
	["healthBarClassColor"] = true,
	["barFontFlags"] = "OUTLINE",
	["tipTacBorderColor"] = {
		0.5215686274509804, -- [1]
		0.5215686274509804, -- [2]
		0.6901960784313725, -- [3]
		1, -- [4]
	},
	["hideTipsInCombat"] = false,
	["classification_rare"] = "%s|r (Rare) ",
	["colReactBack2"] = {
		0.3, -- [1]
		0, -- [2]
		0, -- [3]
		1, -- [4]
	},
	["optionsBottom"] = 330.2222900390625,
	["colReactText3"] = "|cffff7f00",
	["updateFreq"] = 0.5,
	["manaBar"] = true,
	["gradientColor"] = {
		0.8, -- [1]
		0.8, -- [2]
		0.8, -- [3]
		0.2, -- [4]
	},
	["fadeTime"] = 0.6,
	["anchorPointUnit"] = "BOTTOMRIGHT",
	["itemQualityBorder"] = true,
	["barFontFace"] = "Fonts\\FRIZQT__.TTF",
	["barFontSize"] = 12,
	["showGuild"] = "guild",
	["gttScale"] = 1,
	["colReactBack3"] = {
		0.3, -- [1]
		0.15, -- [2]
		0, -- [3]
		1, -- [4]
	},
	["preFadeTime"] = 0.6,
	["pvpName"] = true,
	["reactText"] = false,
	["showTarget"] = "last",
	["top"] = 174.7205810546875,
	["tipBackdropBG"] = "Interface\\Tooltips\\UI-Tooltip-Background",
	["left"] = 1238.958862304688,
	["tipColor"] = {
		0.1, -- [1]
		0.1, -- [2]
		0.2, -- [3]
		1, -- [4]
	},
	["colReactText2"] = "|cffff0000",
	["mouseOffsetX"] = 10,
	["healthBarText"] = "none",
	["colReactText7"] = "|cff808080",
	["colReactBack5"] = {
		0, -- [1]
		0.3, -- [2]
		0.1, -- [3]
		1, -- [4]
	},
	["auraMaxRows"] = 2,
	["colLevel"] = "|cffc0c0c0",
	["classification_normal"] = "%s ",
	["gradientTip"] = false,
	["reactColoredBackdrop"] = false,
	["colReactText6"] = "|cff25c1eb",
	["modifyFonts"] = true,
	["fontFace"] = "Fonts\\FRIZQT__.TTF",
	["colReactBack4"] = {
		0.3, -- [1]
		0.3, -- [2]
		0, -- [3]
		1, -- [4]
	},
	["tipBackdropEdge"] = "Interface\\None",
	["classColoredBorder"] = false,
	["fontSize"] = 12,
	["colReactText4"] = "|cffffff00",
	["tipTacColor"] = {
		0.1, -- [1]
		0.1, -- [2]
		0.2, -- [3]
		1, -- [4]
	},
	["showTargetedBy"] = false,
	["showBuffs"] = false,
	["selfDebuffsOnly"] = false,
	["showStatus"] = true,
	["healthBar"] = true,
	["colReactText5"] = "|cff00ff00",
	["colSameGuild"] = "|cffff32ff",
	["anchorType"] = "normal",
	["classification_worldboss"] = "%s|r (Boss) ",
	["backdropInsets"] = 3.5,
	["tipScale"] = 1,
	["manaBarText"] = "none",
	["showTalents"] = false,
	["colorNameByClass"] = true,
	["anchorTypeUnit"] = "normal",
	["classification_rareelite"] = "+%s|r (Rare) ",
	["auraSize"] = 18,
	["healthBarColor"] = {
		0.3, -- [1]
		0.9, -- [2]
		0.3, -- [3]
		1, -- [4]
	},
	["colRace"] = "|cffffffff",
	["tipBorderColor"] = {
		0.3, -- [1]
		0.3, -- [2]
		0.4, -- [3]
		1, -- [4]
	},
	["barTexture"] = "Interface\\AddOns\\rTextures\\statusbar",
	["mouseOffsetY"] = 10,
	["optionsLeft"] = 641.3333740234375,
	["hookTips"] = false,
	["colReactBack6"] = {
		0, -- [1]
		0, -- [2]
		0.5, -- [3]
		1, -- [4]
	},
	["aurasAtBottom"] = false,
	["classification_elite"] = "+%s ",
	["hideWorldTips"] = true,
}
