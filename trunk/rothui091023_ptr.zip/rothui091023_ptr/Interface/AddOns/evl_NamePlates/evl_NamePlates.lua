-- This mod is made by evl
-- http://wow.curseforge.com/projects/evl/

  --chat output func
  local function am(text)
    DEFAULT_CHAT_FRAME:AddMessage(text)
  end

local evl_NamePlates = CreateFrame("Frame", nil, UIParent)

local texture = "Interface\\Addons\\rTextures\\statusbar"
local bordertexture = "Interface\\Addons\\rTextures\\d3_nameplate_border"
local bordertexture2 = "Interface\\Addons\\rTextures\\d3_nameplate_border_glow"
local d3font = "FONTS\\FRIZQT__.ttf"

local function IsNamePlateFrame(frame)
  if frame:GetName() then
    return false
  end
  
  --local overlayRegion = frame:GetRegions()
  local overlayRegion = select(2,frame:GetRegions())
  if not overlayRegion or overlayRegion:GetObjectType() ~= "Texture" or overlayRegion:GetTexture() ~= "Interface\\Tooltips\\Nameplate-Border" then
    return false
  end
  
  return true
end

function evl_NamePlates:new()
  self:SetScript("OnUpdate", self.onUpdate)
end

local lastUpdate = 0
local frame
function evl_NamePlates:onUpdate(elapsed)
  lastUpdate = lastUpdate + elapsed
  
  if lastUpdate > 1 then
    lastUpdate = 0

    for i = 1, select("#", WorldFrame:GetChildren()) do
      frame = select(i, WorldFrame:GetChildren())
    
      if not frame.background and IsNamePlateFrame(frame) then 
        self:setupNamePlate(frame)
      end
    end  
  end
end

local healthBar, castBar
local overlayRegion, highlightRegion, nameTextRegion, bossIconRegion, levelTextRegion, raidIconRegion
function evl_NamePlates:setupNamePlate(frame)
  healthBar, castBar = frame:GetChildren()
  threatRegion, overlayRegion, _, _, _, highlightRegion, nameTextRegion, levelTextRegion, bossIconRegion, raidIconRegion, dragon = frame:GetRegions()
  
  if dragon then
    dragon:SetAlpha(0)
  end
  
  -- Border on top
  --overlayRegion:Hide()
  overlayRegion:SetTexture(bordertexture)
  overlayRegion:ClearAllPoints()
  overlayRegion:SetPoint("TOPLEFT",healthBar,"TOPLEFT",-19,9)
  overlayRegion:SetPoint("BOTTOMRIGHT",healthBar,"BOTTOMRIGHT",16,-10)
  
  threatRegion:SetTexture(bordertexture2)
  threatRegion:ClearAllPoints()
  threatRegion:SetTexCoord(0,1,0,1)
  threatRegion:SetPoint("TOPLEFT",healthBar,"TOPLEFT",-19,9)
  threatRegion:SetPoint("BOTTOMRIGHT",healthBar,"BOTTOMRIGHT",16,-10)
  
  -- Icons we don't need
  bossIconRegion:Hide()
  
  -- Name text
  nameTextRegion:ClearAllPoints()
  nameTextRegion:SetPoint("BOTTOM", healthBar, "TOP", 0, 3)
  nameTextRegion:SetFont(d3font, 14, "THINOUTLINE")
  nameTextRegion:SetShadowColor(1,1,1,0)
  
  -- Level text
  levelTextRegion:ClearAllPoints()
  levelTextRegion:SetPoint("LEFT", healthBar, "RIGHT", 15, -1)
  levelTextRegion:SetFont(d3font, 14, "THINOUTLINE")
  levelTextRegion:SetShadowColor(1,1,1,0)
  
  -- Highlight which shows up on mouseover
  highlightRegion:SetAlpha(0)
  
  -- Health bar
  healthBar:SetStatusBarTexture(texture)
  
  -- Background
  background = healthBar:CreateTexture(nil, "BORDER")
  background:SetAllPoints(healthBar)
  background:SetTexture(texture)
  background:SetVertexColor(0.15, 0.15, 0.15, 1) 
  
  frame.background = background
end

evl_NamePlates:new()