
Bongos2DB = {
	["profileKeys"] = {
		["Loral - Eredar"] = "Loral - Eredar",
		["Grombur - Eredar"] = "Grombur - Eredar",
		["Rothar - Eredar"] = "Rothar - Eredar",
		["Astone - Eredar"] = "Astone - Eredar",
	},
	["profiles"] = {
		["Loral - Eredar"] = {
			["showMacros"] = false,
			["showHotkeys"] = false,
			["showMinimap"] = false,
			["highlightBuffs"] = false,
			["locked"] = 1,
			["sticky"] = false,
			["bars"] = {
				{
					["p1"] = 1,
					["point"] = "BOTTOMLEFT",
					["size"] = 10,
					["scale"] = 0.77,
					["p4"] = 4,
					["p2"] = 2,
					["cols"] = 5,
					["yOff"] = 120.7020034790039,
					["xOff"] = 678.037353515625,
					["p5"] = 5,
					["spacing"] = 4,
					["s1"] = 6,
					["p3"] = 3,
					["s3"] = 8,
					["s2"] = 7,
				}, -- [1]
				{
					["yOff"] = -294.3334350585938,
					["xOff"] = -358.3334350585938,
					["point"] = "TOPRIGHT",
					["hidden"] = true,
				}, -- [2]
				{
					["yOff"] = 283.7382202148438,
					["xOff"] = -15.23834737141897,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 5,
					["scale"] = 0.8,
					["fadeAlpha"] = 0,
					["cols"] = 1,
				}, -- [3]
				{
					["yOff"] = -147.7904663085938,
					["xOff"] = -212.669677734375,
					["point"] = "TOPRIGHT",
					["hidden"] = true,
				}, -- [4]
				{
					["yOff"] = 46.51470947265625,
					["xOff"] = 710.2354736328125,
					["point"] = "BOTTOMLEFT",
					["spacing"] = 4,
					["scale"] = 0.75,
					["size"] = 10,
				}, -- [5]
				{
					["yOff"] = 120.7019119262695,
					["xOff"] = -687.7474281301193,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 4,
					["scale"] = 0.77,
					["size"] = 10,
					["cols"] = 5,
				}, -- [6]
				{
					["yOff"] = -192.489013671875,
					["xOff"] = 227.2985992431641,
					["point"] = "TOPLEFT",
					["hidden"] = true,
				}, -- [7]
				{
					["yOff"] = -343.6510620117188,
					["xOff"] = -305.3173828125,
					["point"] = "TOPRIGHT",
					["hidden"] = true,
				}, -- [8]
				{
					["yOff"] = -128.2857055664063,
					["xOff"] = 202.9175415039063,
					["point"] = "TOPLEFT",
					["hidden"] = true,
				}, -- [9]
				{
					["hidden"] = true,
				}, -- [10]
				["class"] = {
					["yOff"] = 224.0040740966797,
					["xOff"] = -777.908513387044,
					["point"] = "BOTTOMRIGHT",
					["space"] = 10,
					["hidden"] = true,
					["scale"] = 0.8,
				},
				["bags"] = {
					["yOff"] = -202.6221923828125,
					["xOff"] = -247.558837890625,
					["point"] = "TOPRIGHT",
					["showKeyring"] = true,
					["hidden"] = true,
				},
				["menu"] = {
					["yOff"] = -249.0097045898438,
					["xOff"] = -208.800048828125,
					["point"] = "TOPRIGHT",
					["hidden"] = true,
				},
				["pet"] = {
					["yOff"] = -262.3334350585938,
					["xOff"] = 553,
					["point"] = "TOPLEFT",
				},
			},
			["rangeColor"] = {
				["g"] = 0.06666666666666667,
				["b"] = 0,
			},
		},
		["Grombur - Eredar"] = {
			["showMacros"] = false,
			["showHotkeys"] = 1,
			["showMinimap"] = false,
			["sticky"] = false,
			["locked"] = 1,
			["highlightBuffs"] = false,
			["bars"] = {
				{
					["p1"] = 1,
					["point"] = "BOTTOMLEFT",
					["size"] = 10,
					["scale"] = 0.77,
					["p4"] = 4,
					["p2"] = 2,
					["cols"] = 5,
					["yOff"] = 120.7020034790039,
					["xOff"] = 678.037353515625,
					["p5"] = 5,
					["spacing"] = 4,
					["s1"] = 6,
					["p3"] = 3,
					["s3"] = 8,
					["s2"] = 7,
				}, -- [1]
				{
					["yOff"] = -294.3334350585938,
					["xOff"] = -358.3334350585938,
					["point"] = "TOPRIGHT",
					["hidden"] = true,
				}, -- [2]
				{
					["yOff"] = 283.7382202148438,
					["fadeAlpha"] = 0,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 5,
					["scale"] = 0.8,
					["xOff"] = -15.23834737141897,
					["cols"] = 1,
				}, -- [3]
				{
					["yOff"] = -147.7904663085938,
					["xOff"] = -212.669677734375,
					["point"] = "TOPRIGHT",
					["hidden"] = true,
				}, -- [4]
				{
					["yOff"] = 46.51470947265625,
					["xOff"] = 710.2354736328125,
					["point"] = "BOTTOMLEFT",
					["spacing"] = 4,
					["scale"] = 0.75,
					["size"] = 10,
				}, -- [5]
				{
					["yOff"] = 120.7019119262695,
					["xOff"] = -687.7474281301193,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 4,
					["scale"] = 0.77,
					["size"] = 10,
					["cols"] = 5,
				}, -- [6]
				{
					["yOff"] = -192.489013671875,
					["xOff"] = 227.2985992431641,
					["point"] = "TOPLEFT",
					["hidden"] = true,
				}, -- [7]
				{
					["yOff"] = -343.6510620117188,
					["xOff"] = -305.3173828125,
					["point"] = "TOPRIGHT",
					["hidden"] = true,
				}, -- [8]
				{
					["yOff"] = -128.2857055664063,
					["xOff"] = 202.9175415039063,
					["point"] = "TOPLEFT",
					["hidden"] = true,
				}, -- [9]
				{
					["hidden"] = true,
				}, -- [10]
				["class"] = {
					["yOff"] = -204.771484375,
					["xOff"] = -523.0570678710938,
					["point"] = "TOPRIGHT",
					["hidden"] = true,
				},
				["bags"] = {
					["yOff"] = -202.6221923828125,
					["xOff"] = -247.558837890625,
					["point"] = "TOPRIGHT",
					["showKeyring"] = true,
					["hidden"] = true,
				},
				["menu"] = {
					["yOff"] = -249.0097045898438,
					["xOff"] = -208.800048828125,
					["point"] = "TOPRIGHT",
					["hidden"] = true,
				},
				["pet"] = {
					["yOff"] = 2.436742782592773,
					["fadeAlpha"] = 0,
					["point"] = "BOTTOMLEFT",
					["spacing"] = 5,
					["scale"] = 0.6,
					["xOff"] = 944.6929321289063,
				},
			},
			["rangeColor"] = {
				["g"] = 0.06666666666666667,
				["b"] = 0,
			},
		},
		["Rothar - Eredar"] = {
			["showMacros"] = false,
			["showHotkeys"] = false,
			["showMinimap"] = false,
			["highlightBuffs"] = false,
			["sticky"] = false,
			["locked"] = 1,
			["bars"] = {
				{
					["s1"] = 6,
					["point"] = "BOTTOMLEFT",
					["s2"] = 7,
					["scale"] = 0.77,
					["size"] = 10,
					["spacing"] = 4,
					["cols"] = 5,
					["yOff"] = 120.7020034790039,
					["xOff"] = 678.037353515625,
					["p5"] = 5,
					["p4"] = 4,
					["p2"] = 2,
					["p3"] = 3,
					["s3"] = 8,
					["p1"] = 1,
				}, -- [1]
				{
					["yOff"] = -294.3334350585938,
					["xOff"] = -358.3334350585938,
					["point"] = "TOPRIGHT",
					["hidden"] = true,
				}, -- [2]
				{
					["yOff"] = 283.7382202148438,
					["xOff"] = -15.23834737141897,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 5,
					["scale"] = 0.8,
					["fadeAlpha"] = 0,
					["cols"] = 1,
				}, -- [3]
				{
					["yOff"] = -147.7904663085938,
					["xOff"] = -212.669677734375,
					["point"] = "TOPRIGHT",
					["hidden"] = true,
				}, -- [4]
				{
					["yOff"] = 46.51470947265625,
					["xOff"] = 710.2354736328125,
					["point"] = "BOTTOMLEFT",
					["spacing"] = 4,
					["scale"] = 0.75,
					["size"] = 10,
				}, -- [5]
				{
					["yOff"] = 120.7019119262695,
					["xOff"] = -687.7474281301193,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 4,
					["scale"] = 0.77,
					["cols"] = 5,
					["size"] = 10,
				}, -- [6]
				{
					["yOff"] = -192.489013671875,
					["xOff"] = 227.2985992431641,
					["point"] = "TOPLEFT",
					["hidden"] = true,
				}, -- [7]
				{
					["yOff"] = -343.6510620117188,
					["xOff"] = -305.3173828125,
					["point"] = "TOPRIGHT",
					["hidden"] = true,
				}, -- [8]
				{
					["yOff"] = -128.2857055664063,
					["xOff"] = 202.9175415039063,
					["point"] = "TOPLEFT",
					["hidden"] = true,
				}, -- [9]
				{
					["hidden"] = true,
				}, -- [10]
				["menu"] = {
					["yOff"] = -249.0097045898438,
					["xOff"] = -208.800048828125,
					["point"] = "TOPRIGHT",
					["hidden"] = true,
				},
				["bags"] = {
					["yOff"] = -202.6221923828125,
					["xOff"] = -247.558837890625,
					["point"] = "TOPRIGHT",
					["showKeyring"] = true,
					["hidden"] = true,
				},
				["pet"] = {
					["yOff"] = -262.3334350585938,
					["xOff"] = 553,
					["point"] = "TOPLEFT",
				},
				["class"] = {
					["yOff"] = -204.771484375,
					["xOff"] = -523.0570678710938,
					["point"] = "TOPRIGHT",
					["hidden"] = true,
				},
			},
			["showEmpty"] = 1,
			["rangeColor"] = {
				["g"] = 0.06666666666666667,
				["b"] = 0,
			},
		},
		["Astone - Eredar"] = {
			["bars"] = {
				{
					["p5"] = 5,
					["p4"] = 4,
					["p2"] = 2,
					["p3"] = 3,
					["p1"] = 1,
				}, -- [1]
				{
				}, -- [2]
				{
				}, -- [3]
				{
				}, -- [4]
				{
				}, -- [5]
				{
				}, -- [6]
				{
				}, -- [7]
				{
				}, -- [8]
				{
				}, -- [9]
				{
				}, -- [10]
				["bags"] = {
					["yOff"] = 4.999998569488525,
					["xOff"] = -92.3333740234375,
					["point"] = "BOTTOMRIGHT",
					["showKeyring"] = true,
				},
				["pet"] = {
					["yOff"] = -233.0762939453125,
					["xOff"] = -434.8857421875,
					["point"] = "TOPRIGHT",
				},
				["menu"] = {
					["yOff"] = 7.000001907348633,
					["xOff"] = -345.3334350585938,
					["point"] = "BOTTOMRIGHT",
				},
			},
		},
	},
}
BongosVersion = "1.10.1"
