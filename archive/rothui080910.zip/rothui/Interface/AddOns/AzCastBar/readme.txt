AzCastBar
---------
A highly customizable and lightweight casting bar replacement mod with support for saved profiles and plugins.

Originally comes with the following plugins: casting bar for player, target, focus and pet, as well as a mirror bar. The Mirror Bar is the one which shows breath, feign death and fatigue.

The option dialog along with the saved profiles are Load on Demand which means it will only be loaded once you open the Options.

The player cast bar supports safe zone indication. This is basically your latency, when the spellcast has passed this point, you can safely cancel the cast and have the spell still fire.

The slash command for AzCastBar is /acb. Using it will open the the option dialog.

Support for Plugins
-------------------
AzCastBar is build up around the possibility to add more bars with different functions.
Normal castbar and mirror bars are in the core part of the addon.