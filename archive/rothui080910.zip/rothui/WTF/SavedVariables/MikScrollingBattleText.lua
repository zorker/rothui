
MSBTProfiles_SavedVars = {
	["profiles"] = {
		["Default"] = {
			["critFontName"] = "Friz",
			["damageColoringDisabled"] = true,
			["animationSpeed"] = 50,
			["partialColoringDisabled"] = true,
			["creationVersion"] = 5.1,
			["critFontSize"] = 25,
			["events"] = {
				["OUTGOING_SPELL_BLOCK"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_BUFF_FADE"] = {
					["message"] = "--%sl",
					["colorR"] = 0.01568627450980392,
					["colorG"] = 0.5372549019607843,
					["disabled"] = true,
				},
				["NOTIFICATION_DEBUFF_FADE"] = {
					["message"] = "--%sl",
					["colorB"] = 0.02352941176470588,
					["colorG"] = 0,
					["colorR"] = 0.5137254901960784,
				},
				["PET_OUTGOING_SPELL_DAMAGE"] = {
					["message"] = "%a (%s)",
				},
				["OUTGOING_MISS"] = {
					["alwaysSticky"] = true,
				},
				["INCOMING_DAMAGE_CRIT"] = {
					["message"] = "*%a*",
				},
				["INCOMING_BLOCK"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_DODGE"] = {
					["alwaysSticky"] = true,
				},
				["PET_OUTGOING_DAMAGE_CRIT"] = {
					["message"] = "%a",
				},
				["PET_OUTGOING_SPELL_DAMAGE_CRIT"] = {
					["message"] = "%a (%s)",
				},
				["INCOMING_DAMAGE"] = {
					["message"] = "%a",
				},
				["PET_OUTGOING_DAMAGE"] = {
					["message"] = "%a",
				},
				["PET_INCOMING_DAMAGE"] = {
					["message"] = "(%n) -%a",
				},
				["NOTIFICATION_NPC_KILLING_BLOW"] = {
					["alwaysSticky"] = false,
					["fontSize"] = false,
				},
				["NOTIFICATION_COMBAT_ENTER"] = {
					["message"] = "++combat",
				},
				["NOTIFICATION_PC_KILLING_BLOW"] = {
					["disabled"] = true,
					["fontSize"] = false,
				},
				["NOTIFICATION_ITEM_BUFF_FADE"] = {
					["message"] = "--%sl",
					["colorR"] = 0.4784313725490196,
					["colorG"] = 0,
					["colorB"] = 0.580392156862745,
				},
				["INCOMING_MISS"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_RESIST"] = {
					["message"] = "RESIST (%s)",
					["soundFile"] = "LowMana",
					["alwaysSticky"] = true,
				},
				["OUTGOING_DODGE"] = {
					["alwaysSticky"] = true,
				},
				["OUTGOING_SPELL_PARRY"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_DEBUFF"] = {
					["message"] = "++%sl",
					["colorB"] = 0.04705882352941176,
					["colorG"] = 0,
					["colorR"] = 0.5019607843137255,
				},
				["NOTIFICATION_EXPERIENCE_GAIN"] = {
					["fontSize"] = false,
					["alwaysSticky"] = false,
					["disabled"] = false,
				},
				["OUTGOING_SPELL_MISS"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_MONSTER_EMOTE"] = {
					["fontSize"] = 20,
					["alwaysSticky"] = true,
					["scrollArea"] = "Notification",
				},
				["OUTGOING_BLOCK"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_POWER_GAIN"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_BUFF"] = {
					["message"] = "++%sl",
					["colorR"] = 0.02352941176470588,
					["colorG"] = 0.396078431372549,
					["disabled"] = true,
				},
				["NOTIFICATION_ENEMY_BUFF"] = {
					["disabled"] = true,
				},
				["OUTGOING_PARRY"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_EXTRA_ATTACK"] = {
					["message"] = "%sl",
					["fontSize"] = false,
					["alwaysSticky"] = false,
				},
				["INCOMING_DODGE"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_MONEY"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_ITEM_BUFF"] = {
					["message"] = "++%sl",
					["colorB"] = 0.5607843137254902,
					["colorG"] = 0.1176470588235294,
					["colorR"] = 0.5411764705882353,
				},
				["NOTIFICATION_COOLDOWN"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_DOT"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_COMBAT_LEAVE"] = {
					["message"] = "--combat",
				},
				["INCOMING_PARRY"] = {
					["disabled"] = true,
				},
			},
			["hideNames"] = true,
			["hideSkills"] = true,
			["normalFontName"] = "Friz",
			["scrollAreas"] = {
				["Static"] = {
					["disabled"] = true,
				},
				["Outgoing"] = {
					["stickyDirection"] = "Up",
					["scrollWidth"] = 10,
					["offsetX"] = 203,
					["behavior"] = "MSBT_NORMAL",
					["offsetY"] = -88,
					["animationStyle"] = "Straight",
					["direction"] = "Up",
				},
				["Incoming"] = {
					["direction"] = "Up",
					["offsetX"] = -200,
					["behavior"] = "MSBT_NORMAL",
					["offsetY"] = -91,
					["animationStyle"] = "Straight",
					["scrollWidth"] = 10,
				},
				["Notification"] = {
					["stickyDirection"] = "Up",
					["scrollHeight"] = 160,
					["offsetX"] = -171,
					["offsetY"] = 129,
					["direction"] = "Up",
				},
			},
			["triggers"] = {
				["MSBT_TRIGGER_NIGHTFALL"] = {
					["fontSize"] = 32,
				},
				["MSBT_TRIGGER_REVENGE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_VICTORY_RUSH"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_OVERPOWER"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_EXECUTE"] = {
					["disabled"] = true,
				},
			},
		},
	},
}
